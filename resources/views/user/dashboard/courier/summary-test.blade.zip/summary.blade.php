@extends('user.dashboard.layout.master')
@section('user-contant')
<style>
    .aa{
        color:rgb(0,32,122);
    }
    .bb{
      color:rgb(0,112,192);  
    }
    .cc{
      color:rgb(86,131,55);  
    }
    .dd{
      color:rgb(255,193,3);  
    }
    .ee{
      color:rgb(255,0,0);  
    }
    .ff{
      color:rgb(64,64,64);  
    }
    .gg{
      color:rgb(255,0,0);  
    }
    .hh{
      color:rgb(255,0,0);  
    }
     .ii{
      color:rgb(255,220,132);  
    }
    .jj{
      color:rgb(84,130,53);  
    }
     .kk{
      color:rgb(117,62,63);  
    }
    .card-header{
        border-bottom:0px !important;
    }
    
    
    
    .card .card-header {
    /*border-bottom-color: #f9f9f9;*/
    /* line-height: 30px; */
    -ms-grid-row-align: center;
    align-self: center;
    width: 100%;
    padding: 10px 16px !important;
    display: flex;
    align-items: center;
}


.card .card-header h4 {
    font-size: 17px;
    line-height: 28px;
   /*padding: 10px 16px !important;*/
    margin-bottom: 0;
    color: #212529;
  
}
.delivery_addcss h4{
     font-size: 15px;
      color: #212529;
       padding: 10px 16px !important;
}
.grid-item {
    word-wrap: break-word; /* Break long words if necessary */
    white-space: pre-wrap; /* Preserve whitespace and wrap the text */
    overflow-wrap: break-word; /* Handle word breaking */
    word-break: break-word; /* Handle word breaking in some older browsers */
    max-width: 100%; /* Ensure it doesn't overflow its container */
}

.list-group-item.active {
    background: #ffc107;
}
/* end common class */
.top-status ul {
    list-style: none;
    display: flex;
    justify-content: space-around;
    justify-content: center;
    flex-wrap: wrap;
    padding: 0;
    margin: 0;
}
.top-status ul li {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: #fff;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    border: 8px solid #ddd;
    box-shadow: 1px 1px 10px 1px #ddd inset;
    margin: 10px 5px;
}
.top-status ul li.active {
    border-color: #ffc107;
    box-shadow: 1px 1px 20px 1px #ffc107 inset;
}
/* end top status */

ul.timeline {
    list-style-type: none;
    position: relative;
}
ul.timeline:before {
    content: ' ';
    background: #d4d9df;
    display: inline-block;
    position: absolute;
    left: 29px;
    width: 2px;
    height: 100%;
    z-index: 400;
}
ul.timeline > li {
    margin: 20px 0;
    padding-left: 30px;
}
ul.timeline > li:before {
    content: '\2713';
    background: #fff;
    display: inline-block;
    position: absolute;
    border-radius: 50%;
    border: 0;
    left: 5px;
    width: 50px;
    height: 50px;
    z-index: 400;
    text-align: center;
    line-height: 50px;
    color: #d4d9df;
    font-size: 24px;
    border: 2px solid #d4d9df;
}
ul.timeline > li.active:before {
    content: '\2713';
    background: #28a745;
    display: inline-block;
    position: absolute;
    border-radius: 50%;
    border: 0;
    left: 5px;
    width: 50px;
    height: 50px;
    z-index: 400;
    text-align: center;
    line-height: 50px;
    color: #fff;
    font-size: 30px;
    border: 2px solid #28a745;
}
/* end timeline */
</style>
<div class="loader"></div>
<div class="main-content">
            <section class="section">
                <div class="row ">
                    <div class="col-md-6">
                        <div class="col-12">

                            <div class="card">

                            
                            @if(!empty($singleproquery) && count($singleproquery) > 0)

                            @foreach($singleproquery as $data)

                            <div class="card-header">
                                    <h4 style="border-bottom:1px solid #c7cccf; width:100%;">Orders Shipment Summary</h4>
                            </div>
                            </hr>
                <div class="row ">

                    <div class="col-md-12">
                        
                            <div class="card-header">
                                <h4 style="border-bottom:1px solid black;">Order Information</h4>

                            </div>
                            <table class="table table-sm dsfffd">

                                <tbody>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Order Number :</th>
                                        <td>{{$data->orderno ?? ''}}</td>

                                    </tr>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>AWB Number :</th>
                                        <td>{{$data->Awb_Number ?? ''}}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Date :</th>
                                        <td>{{ date('d-m-Y', strtotime($data->Rec_Time_Date)) }}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Order Type :</th>
                                        <td>{{$data->Order_Type ?? ''}}</td>
                                        
                                    </tr>

                                    @if($data->Order_Type ==  'cod' || $data->Order_Type ==  'Cod' || $data->Order_Type ==  'COD')

                                    <tr>
                                        <th scope="row"></th>
                                        <th>COD Value :</th>
                                        <td>{{$data->Cod_Amount ?? ''}}</td>
                                        
                                    </tr>

                                    @endif

                                    <tr>
                                        <th scope="row"></th>
                                        <th>Order Status :</th>
                                        <td>{{ $data->order_status1 == 'Shipped' ? 'Pending Pickup' : $data->order_status1 }}</td>
                                    </tr>

                                    
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Courier :</th>
                                        <td>{{$data->courier_name ?? ''}}</td>
                                    </tr>
                                        <tr>
                                        <th scope="row"></th>
                                        <th>Declarest Weight :</th>
                                        <td>{{$data->Actual_Weight ?? ''}} KG</td>

                                    </tr>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Physical Weight :</th>
                                        <td>{{$data->Actual_Weight ?? ''}}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Dimension :</th>
                                        <td>{{$data->Length ?? ''}} x
                                        {{$data->Width ?? ''}} x
                                        {{$data->Height ?? ''}}</td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th>Volumetric Weight :</th>
                                        <td>{{$data->VolumetricWeigh ?? ''}}</td>
                                    </tr>
                                </tbody>
                            </table>
                                       
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card-header">
                        <h4 style="border-bottom:1px solid black;">Shipping Information</h4>
                        </div>
                    
                        <div class="delivery_addcss">
                            <h4>Delivery Address</h4>

                        </div>
                        <table class="table table-sm dsfffd">

                            <tbody>
                                <tr>
                                    <th scope="row"></th>
                                    <th>Name :</th>
                                    <td>{{$data->Name ?? ''}}</td>
                                    

                                </tr>
                                <tr>
                                    <th scope="row"></th>
                                    <th>Address1 :</th>
                                    <td>{{$data->Address ?? ''}}</td>
                                    
                                </tr>
                                    <tr>
                                    <th scope="row"></th>
                                    <th>Address2 :</th>
                                    <td>{{$data->Address2 ?? ''}}</td>
                                    
                                </tr>
                                    <tr>
                                    <th scope="row"></th>
                                    <th>Landmark :</th>
                                    <td>{{$data->landmark ?? ''}}</td>
                                    
                                </tr>
                                <tr>
                                    <th scope="row"></th>
                                    <th>Mobile :</th>
                                    <td>{{$data->Mobile ?? ''}}</td>
                                    
                                </tr>
                                <tr>
                                    <th scope="row"></th>
                                    <th>City :</th>
                                    <td>{{$data->City ?? ''}}</td>
                                    
                                </tr>
                                <tr>
                                    <th scope="row"></th>
                                    <th>State :</th>
                                    <td>{{$data->State ?? ''}}</td>
                                    
                                </tr>
                                <tr>
                                    <th scope="row"></th>
                                    <th>Country :</th>
                                    <td>INDIA</td>
                                </tr>
                                <tr>
                                    <th scope="row"></th>
                                    <th>Pincode :</th>
                                    <td>{{$data->Pincode ?? ''}}</td>
                                </tr>

                            </tbody>
                        </table>
                    
                   </div>
                
                </div>

                <div class="row">
                    <div class="col-md-12">
                        
                            <div class="delivery_addcss">
                                <h4>Pickup Address</h4>
                            </div>
                            <table class="table table-sm dsfffd">

                                <tbody>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Name :</th>
                                        <td>{{$data->ware_name ?? ''}}</td>
                                       

                                    </tr>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>Address :</th>
                                        <td>{{$data->sell_add ?? ''}}</td>
                                        
                                    </tr>
                                    <tr>
                                        <th scope="row"></th>
                                        <th>City :</th>
                                        <td>{{$data->pickcity ?? ''}}</td>
                                        
                                    </tr>

                                    <tr>
                                        <th scope="row"></th>
                                        <th>State :</th>
                                        <td>{{$data->pick_state ?? ''}}</td>
                                        
                                    </tr>

                                    <tr>
                                        <th></th>
                                        <th>Mobile :</th>
                                        <td>{{$data->sell_phone ?? ''}}</td>
                                        
                                    </tr>

                                    <tr>
                                        <th></th>
                                        <th>Pincode :</th>
                                        <td>{{$data->sell_pin ?? ''}}</td>
                                        
                                    </tr>

                                </tbody>
                            </table>
                            
                        </div> 
            </div>
            <div class="row">
                <div class="card-body">
                    <table class="table table-sm">
                        <thead>
                            <tr style="color: blueviolet;">
                                <th scope="col"></th>
                                <th scope="col">Product</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Value</th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr>
                                <th scope="row"></th>
                                <td class="grid-item">{{$data->Item_Name ?? ''}}</td>
                                <td>{{$data->Quantity ?? ''}}</td>
                                <td>{{$data->Invoice_Value ?? ''}}</td>
                                
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            

            @endforeach
            </div>




                        </div>

                    </div>

            <div class="col-md-6">
                        <div>
                            <div class="card ">
                                 <div class="row">
                                <div class="card-header">
                                 
                                   <div class="col-sm-7">
                                        <h3 style="    font-size: 14px; color: black;">
                                     <img src="{{ asset('user/assets/img/route.jpg') }}" alt="shadow" class="img-fluid" style="width: 20%; height: 80px;" >
                                        OrderTracking/Real Time
                                        </h3>
                                   </div>
                                  
                                    
                                   <?php
                                
                                $current_statusdata = $data->order_status1 ?? '';
                                
                                    
                                 $current_statusdata= $current_statusdata == 'Shipped'? 'Pending Pickup':$current_statusdata;
                                  $current_statusdata= $current_statusdata == 'In Transit'? 'Intransit':$current_statusdata;
                                   $current_statusdata= $current_statusdata == 'Delivered'? 'Delivered':$current_statusdata;
                                    $current_statusdata= $current_statusdata == 'OFD'? 'Out For Delivery':$current_statusdata;
                                      $current_statusdata= $current_statusdata == 'RTO'? 'RTO':$current_statusdata;
                                        $current_statusdata= $current_statusdata == 'Lost'? 'Lost':$current_statusdata;
                                      $current_statusdata= $current_statusdata == 'Cancelled'? 'Cancelled':$current_statusdata;
                                       $current_statusdata= $current_statusdata == 'Failed'? 'Failed':$current_statusdata;
                                        $current_statusdata= $current_statusdata == 'Processing'? 'Processing':$current_statusdata;
                                       
                                          $current_statusdata= $current_statusdata == 'Upload'? 'Ready To Ship':$current_statusdata;
                                           $current_statusdata= $current_statusdata == 'Undelivered'? 'Undelivered':$current_statusdata;
                                   ?>
 
                                  <div class="col-sm-5">
                                       <h3 style="font-size: 14px;
                    color: black;">Current Status <span class="<?php if($current_statusdata == 'Pending Pickup') {
                                       echo "aa";
                                       
                                       
                                     }elseif($current_statusdata == 'Intransit'){
                                     
                                     echo "bb";
                                     
                                     }elseif($current_statusdata == 'Delivered'){
                                     
                                     echo "cc";
                                     
                                     }elseif($current_statusdata == 'Out For Delivery'){
                                     
                                     echo "dd";
                                     
                                     }elseif($current_statusdata == 'RTO'){
                                     
                                     echo "ee";
                                     
                                     }elseif($current_statusdata == 'Lost'){
                                     
                                     echo "ff";
                                     
                                     }elseif($current_statusdata == 'Cancelled'){
                                     
                                     echo "gg";
                                     
                                     }
                                     elseif($current_statusdata == 'Failed'){
                                     
                                     echo "hh";
                                     
                                     }
                                      elseif($current_statusdata == 'Processing'){
                                     
                                     echo "ii";
                                     
                                     }
                                     elseif($current_statusdata == 'Ready To Ship'){
                                     
                                     echo "jj";
                                     
                                     } elseif($current_statusdata == 'Undelivered'){
                                     
                                     echo "kk";
                                     
                                     }
                                      
                                     
                                     ?>"><?php echo $current_statusdata ?></span></h3>
                                  </div>
                                      </div>


                                      {{-- New --}}

                                      
                                        <div class="card-body">
                                            <h4>Shipment Tracker</h4>
                                                <ul class="timeline">
                                                    @foreach($allStatusLogs as $logs)

                                                    
                                                    <li class="active">
                                                        <h6>{{$logs->order_status1 ?? ''}}</h6>
                                                        <p class="mb-0 text-muted">{{ date('d-m-Y H:i:s', strtotime($logs->created_at)) }}</p>
                                                        
                                                    </li>
                                                    @endforeach

                                                    {{-- <li class="active">
                                                        <h6>Shipped</h6>
                                                        <p class="mb-0 text-muted">{{ date('d-m-Y H:i:s', strtotime($data->Rec_Time_Stamp)) }}</p>
                                                        
                                                    </li>

                                                    


                                                    <li class="active">
                                                        <h6>{{$logs->order_status1 ?? ''}}</h6>
                                                        <p class="mb-0 text-muted">29 Aug 2024, 11:23 AM</p>
                                                        
                                                    </li> --}}
                                                   


                                                    {{-- <li class="active">
                                                        <h6>Scheduled for Pickup</h6>
                                                        <p class="mb-0 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</p>
                                                        <o class="text-muted">21 March, 2014</p>
                                                    </li>
                                                    <li>
                                                        <h6>In-transit</h6>
                                                        <p class="mb-0 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</p>
                                                        <o class="text-muted">21 March, 2014</p>
                                                    </li>
                                                    <li>
                                                        <h6>Out for delivery</h6>
                                                        <p class="mb-0 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</p>
                                                        <o class="text-muted">21 March, 2014</p>
                                                    </li>
                                                    <li>
                                                        <h6>Delivered</h6>
                                                        <p class="mb-0 text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</p>
                                                        <o class="text-muted">21 March, 2014</p>
                                                    </li> --}}
                                                </ul>
                                        </div>
                                    


                                      {{-- New --}}
                                </div>



                             </div>
                        </div>
                    </div>
                </div>
            </section>
            @else

            <center>
            <h1 style="color:#60baaf">AWB / Order ID Not Found</h1>
            </center>

            @endif
            
</div>



@endsection