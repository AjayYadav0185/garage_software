
@extends('user.dashboard.layout.master')
@section('user-contant')

<div class="loader"></div>

<div class="main-content">
        <section class="section" style="margin-top:-34px;">
            <div class="row">
                <div class="col-12 col-sm-12 col-lg-12">
                    <div class="card ">
                        

                        <div class="card-header">
                            <h4>Print Labels</h4>
                        </div>

                        <div class="printableArea2">

    </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 ">
                                    <div class="card-header">
                                        <h4>Print Shipping Labels</h4>

                                    </div>

                                    {{-- <div class="pretty p-switch">
                                        <input type="checkbox" name="mobile" value="mobile" id="mobilee" <?php
                                            if($data->customermobile== 'Active' )    
                                            {
                                                echo "Checked";
                                            }
                                            else{
                                                echo "";
                                            }
                                            
                                            ?>>
                                        <div class="state p-primary">
                                            <label>Custmer Mobile </label>
                                        </div>

                                    </div> --}}

                                    {{-- <div class="pretty p-switch">
                                        <input type="checkbox" name="sel_mobilee" value="seller mobile" id="sel_mobilee" 
                                        <?php
                                        if($data->sellermobile== 'Active')
                                            {
                                                echo "Checked";
                                            }
                                            else{
                                                echo "";
                                            }
                                            ?>>
                                        <div class="state p-primary">
                                            <label>Seller Mobile </label>
                                            
                                        </div>

                                    </div> --}}

                                    {{-- <div class="pretty p-switch">
                                        <input type="checkbox" name="sel_address" value="seller address" id="sel_address" 
                                        <?php
                                            
                                            if($data->selleraddress== 'Active')   
                                            {
                                                echo "Checked";
                                            }
                                            else{
                                                echo "";
                                            }
                                            
                                            ?>>
                                        <div class="state p-primary">
                                            <label> Seller address </label>
                                           
                                        </div>

                                    </div> --}}

                                    {{-- <div class="pretty p-switch mt-4">
                                        <input type="checkbox" name="seller_rt_address" value="seller return address" id="seller_rt_address" 
                                        <?php
                                        if($data->sellerreturnadd== 'Active')
                                            {
                                                echo "Checked";
                                            }
                                            else{
                                                echo "";
                                            }
                                            ?>>
                                        <div class="state p-primary">
                                            <label>RTO</label>
                                            
                                        </div>

                                    </div> --}}

                                    <?php
                             
                                ?>   
                           <div class="list-inline my-3 ">
                                        <textarea class="form-control"
                                            placeholder="Search Order Details Write AWB Number"
                                            name="shippinglabelawbno" class="my-5"
                                            id="shippinglabelawbno"></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 my-3">
                                            <select class="form-control " id="select_size_css" name="printlabels">
                                                <option value=" ">Select Page Size</option>

                                                <option value="A4 Size">A4 Size</option>

                                                <option value="4X6 Size">4*6 Size</option>

                                                <option value="A6 Size">A6 Size</option>

                                                <option value="A6 Size New">A6 Size New</option>


                                            </select>
                                        </div>
                                        <div class="col-md-2  my-3">
                                            <div class="buttons ">
                                                <!-- <a href="#" class="btn btn-primary form-control"><i class="fa fa-print">&nbsp;&nbsp;Print</i></a> -->
                                                <a href="" id="download_ship_lebel" hidden=""></a>
                                                <input type="button" class="btn btn-primary form-control" value="Print" id="print_ship_level">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                {{-- <div class="col-md-6 ">
                                    <div class="card-header">
                                        <h4>Print Manifest Labels</h4>

                                    </div>
                                    <div class="pretty p-switch">
                                        <input type="checkbox" />
                                        <div class="state p-primary">
                                            <label>Mobile Show</label>
                                        </div>

                                    </div>
                                    <div class="list-inline my-3 ">


                                        <textarea class="form-control"
                                            placeholder="Search Order Details Write AWB Number"
                                            name="shippinglabelawbno" class="my-5"></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 my-3">
                                            <select class="form-control" name="printlabels">
                                                <option value="sss">Select Page Size</option>

                                                <option value="A4 Size" class=" ">A4 Size</option>

                                                <option value="4X6 Size" class=" ">4*6 Size</option>

                                                <option value="A6 Size" class=" ">A6 Size</option>

                                                <option value="A6 Size New" class=" ">A6 Size New</option>


                                            </select>
                                        </div>
                                        <div class="col-md-2  my-3">
                                            <div class="buttons ">
                                                <!-- <a href="#" class="btn btn-primary form-control"><i class="fa fa-print">&nbsp;&nbsp;Print</i></a> -->
                                                <input type="submit" class="btn btn-primary form-control" value="Print">
                                            </div>
                                        </div>
                                    </div>

                                </div> --}}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    

    <script
        src="https://www.jqueryscript.net/demo/jQuery-Plugin-For-Simultaneous-Downloads-With-One-Click-multiDownload/jquery.multiDownload.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/PrintArea/2.4.1/jquery.PrintArea.min.js"></script>
    <script>
    $("#nav a").click(function(e) {
        e.preventDefault();
        $(".toggle").hide();
        var toShow = $(this).attr('href');
        $(toShow).show();
    });

   
    </script>

@endsection